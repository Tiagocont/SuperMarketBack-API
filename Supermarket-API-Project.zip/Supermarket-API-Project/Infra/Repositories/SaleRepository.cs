﻿using Domain.Entities;
using Domain.Interfaces;
using Infra;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Domain.Repositories
{
    public class SaleRepository : ISaleRepository
    {
        private readonly DataContext _context;
        public SaleRepository(DataContext context)
        {
            _context = context;
        }
        public async void Delete(int id)
        {
            var sale = await _context.Sales.FirstOrDefaultAsync(x => x.Id == id);

            if (sale == null)
            {
                throw new Exception("Produto não encontrado.");
            }

            _context.Sales.Remove(sale);

            await _context.SaveChangesAsync();
        }

        public async Task<Sale> Get(int id)
        {
            return await _context.Sales.FirstOrDefaultAsync(x => x.Id == id);
        }
        public async Task<IEnumerable<Sale>> GetAll()
        {
            return await _context.Sales.ToListAsync();
        }

        public void Post(Sale entity)
        {
            _context.Sales.Add(entity);
            _context.SaveChanges();
        }

        public async Task<Sale> Put(Sale sale)
        {
            // Verifica se o produto existe
            var saleToUpdate = await _context.Sales.FirstOrDefaultAsync(x => x.Id == sale.Id);

            if (saleToUpdate == null)
            {
                throw new Exception("Produto não encontrado.");
            }

            // Atualiza os campos do produto existente com os valores do novo produto
            _context.Entry(saleToUpdate).CurrentValues.SetValues(sale);

            // Salva as alterações no banco de dados de forma assíncrona
            await _context.SaveChangesAsync();

            return saleToUpdate;
        }
    }
}
