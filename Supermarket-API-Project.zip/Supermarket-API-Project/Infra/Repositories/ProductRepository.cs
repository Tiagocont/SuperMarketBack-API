﻿using Domain.Entities;
using Domain.Interfaces;
using Infra;
using Microsoft.EntityFrameworkCore;

namespace Domain.Repositories
{
    public class ProductRepository : IProductRepository
    {
        private readonly DataContext _context;

        public ProductRepository(DataContext context)
        {
            _context = context;
        }

        public async void Delete(int id)
        {
            var produto = await _context.Products.FirstOrDefaultAsync(x => x.Id == id);

            if (produto == null)
            {
                throw new Exception("Produto não encontrado.");
            }

            _context.Products.Remove(produto);

            await _context.SaveChangesAsync();
        }

        public async Task<Product> Get(int id)
        {
            return await _context.Products.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<IEnumerable<Product>> GetAll()
        {
            return await _context.Products.ToListAsync();
        }


        public void Post(Product entity)
        {
            _context.Products.Add(entity);
            _context.SaveChanges();
        }

        public async Task<Product> Put(Product product)
        {
            var productToUpdate = await _context.Products.FirstOrDefaultAsync(x => x.Id == product.Id);

            if (productToUpdate == null)
            {
                throw new Exception("Produto não encontrado.");
            }

            _context.Entry(productToUpdate).CurrentValues.SetValues(product);

            await _context.SaveChangesAsync();

            return productToUpdate;
        }


    }
}
