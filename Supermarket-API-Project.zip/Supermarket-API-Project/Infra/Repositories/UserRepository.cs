﻿using Domain.Entities;
using Domain.Interfaces;
using Infra;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;

namespace Domain.Repositories
{
    public class UserRepository : IUserRepository
    {
        private readonly DataContext _context;
        public UserRepository(DataContext context)
        {
            _context = context;
        }

        public async void Delete(int id)
        {
            var user = await _context.Users.FirstOrDefaultAsync(x => x.Id == id);

            if (user == null)
            {
                throw new Exception("Produto não encontrado.");
            }

            _context.Users.Remove(user);

            await _context.SaveChangesAsync();
        }

        public async Task<User> Get(int id)
        {
            return await _context.Users.FirstOrDefaultAsync(x => x.Id == id);
        }

        public async Task<IEnumerable<User>> GetAll()
        {
            return await _context.Users.ToListAsync();
        }


        public void Post(User entity)
        {
            _context.Users.Add(entity);
            _context.SaveChanges();
        }

        public async Task<User> Put(User user)
        {
            var userToUpdate = await _context.Users.FirstOrDefaultAsync(x => x.Id == user.Id);

            if (userToUpdate == null)
            {
                throw new Exception("Produto não encontrado.");
            }

            _context.Entry(userToUpdate).CurrentValues.SetValues(user);

            await _context.SaveChangesAsync();

            return userToUpdate;
        }
    }
}
