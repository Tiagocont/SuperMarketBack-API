﻿using Domain.Interfaces;
using Newtonsoft.Json.Linq;
using System.Net.Http;
using System;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Net;

namespace Infra.Repositories
{
    public class DeliveryRepository : IDeliveryRepository
    {
        private static readonly (double lat, double lon) OsascoCoordinates = (-23.5329, -46.7923); // Coordenadas de Osasco, substitua conforme necessário

        public async Task<(double lat, double lon)> GetCoordinates(string cep)
        {
            string url = $"https://brasilapi.com.br/api/cep/v2/{cep}";

            using HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("User-Agent", "SupermarketAPIProject/1.0");

            var response = await client.GetAsync(url);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception($"Erro ao consultar API: {response.StatusCode}");
            }

            var responseString = await response.Content.ReadAsStringAsync();

            // Desserializa o JSON para o objeto CepResponse
            var data = JsonConvert.DeserializeObject<CepResponse>(responseString);

            // Verifica se as coordenadas estão disponíveis
            if (data.Location == null || data.Location.Coordinates == null)
            {
                throw new Exception("Coordenadas não disponíveis no formato esperado.");
            }

            // Obtém as coordenadas
            double lon = data.Location.Coordinates.Longitude; // Longitude
            double lat = data.Location.Coordinates.Latitude;  // Latitude

            return (lat, lon);
        }

        public class CepResponse
        {
            public Location Location { get; set; }
        }


        public class Coordinates
        {
            public double Longitude { get; set; }
            public double Latitude { get; set; }
        }

        public class Location
        {
            public string Type { get; set; }
            public Coordinates Coordinates { get; set; } 
        }

        public async Task<double> DistanceCalculator((double lat, double lon) origem, (double lat, double lon) destino)
        {
            double R = 6371; // Raio da Terra em quilômetros
            double latOrigemRad = origem.lat * (Math.PI / 180); // Converter latitude de origem para radianos
            double latDestinoRad = destino.lat * (Math.PI / 180); // Converter latitude de destino para radianos
            double deltaLat = (destino.lat - origem.lat) * (Math.PI / 180); // Diferença de latitude
            double deltaLon = (destino.lon - origem.lon) * (Math.PI / 180); // Diferença de longitude

            // Fórmula de Haversine
            double a = Math.Sin(deltaLat / 2) * Math.Sin(deltaLat / 2) +
                       Math.Cos(latOrigemRad) * Math.Cos(latDestinoRad) *
                       Math.Sin(deltaLon / 2) * Math.Sin(deltaLon / 2);

            double c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));

            double distanciaKm = R * c; // Distância em quilômetros

            return distanciaKm;
        }

        public async Task<double> CalculateDeliveryValueAsync(string cep)
        {
            // Obtém as coordenadas do endereço de entrega
            var destinoCoordinates = await GetCoordinates(cep);

            // Calcula a distância entre Osasco e o endereço de destino
            double distance = await DistanceCalculator(OsascoCoordinates, destinoCoordinates);

            double costPerKm = 2.0;
            double deliveryValue = distance * costPerKm;

            return deliveryValue;
        }
    }
}
