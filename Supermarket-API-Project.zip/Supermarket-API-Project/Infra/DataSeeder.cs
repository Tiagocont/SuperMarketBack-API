﻿using Domain.Entities;
using Domain.Enum;
using Infra;

public class DataSeeder
{
    private readonly DataContext _context;

    public DataSeeder(DataContext context)
    {
        _context = context;
    }

    public async Task SeedAsync()
    {
        if (!_context.Products.Any() && !_context.Users.Any()) 
        {
            var products = new List<Product>
            {
                new Product { Id = 1, Name = "Detergente", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.CleaningProduct, Value = (float)1.99 },
                new Product { Id = 2, Name = "Cândida", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.CleaningProduct, Value = (float)12.99 },
                new Product { Id = 3, Name = "Desinfetante", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.CleaningProduct, Value = (float)5.49 },
                new Product { Id = 4, Name = "Limpador Multiuso", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.CleaningProduct, Value = (float)8.99 },
                new Product { Id = 5, Name = "Álcool em Gel", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.CleaningProduct, Value = (float)3.49 },

                new Product { Id = 6, Name = "Refrigerante Lata", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.Beverage, Value = (float)4.99 },
                new Product { Id = 7, Name = "Suco Natural", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.Beverage, Value = (float)6.49 },
                new Product { Id = 8, Name = "Cerveja Lata", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.Beverage, Value = (float)3.99 },
                new Product { Id = 9, Name = "Água Mineral", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.Beverage, Value = (float)1.29 },
                new Product { Id = 10, Name = "Vinho Tinto", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.Beverage, Value = (float)29.99 },

                new Product { Id = 11, Name = "Maçã", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FreshFood, Value = (float)0.99 },
                new Product { Id = 12, Name = "Banana", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FreshFood, Value = (float)1.29 },
                new Product { Id = 13, Name = "Cenoura", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FreshFood, Value = (float)0.79 },
                new Product { Id = 14, Name = "Alface", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FreshFood, Value = (float)2.49 },
                new Product { Id = 15, Name = "Frango", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FreshFood, Value = (float)10.99 },

                new Product { Id = 16, Name = "Legumes Congelados", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FrozenFood, Value = (float)7.99 },
                new Product { Id = 17, Name = "Pizza Congelada", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FrozenFood, Value = (float)25.99 },
                new Product { Id = 18, Name = "Sorvete", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FrozenFood, Value = (float)15.99 },
                new Product { Id = 19, Name = "Peixe Congelado", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FrozenFood, Value = (float)20.99 },
                new Product { Id = 20, Name = "Frutas Congeladas", QuantitiyChoose = 0, QuantityInStock = 100, TypeProduct = EProductType.FrozenFood, Value = (float)8.99 },
            };
            await _context.Products.AddRangeAsync(products);

            var users = new List<User>
            {
                new User { Id = 1, Cpf = "108.055.940-00", Email= "Felipe@email.com", Name="Felipe", Senha= "Senha123" },
                new User { Id = 5, Cpf = "100.200.300-88", Email= "Gustavo@email.com", Name="Gustavo", Senha= "Password123" },
            };
            await _context.Users.AddRangeAsync(users);

            await _context.SaveChangesAsync();
        }
    }
}
