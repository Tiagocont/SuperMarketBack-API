﻿using System.ComponentModel;

namespace Domain.Enum
{
    public enum EProductType
    {
        [Description("Produtos de Limpeza")]
        CleaningProduct = 0, 

        [Description("Bebidas")]
        Beverage = 1,    

        [Description("Alimentos Frescos")]
        FreshFood = 2,     

        [Description("Produtos Congelados")]
        FrozenFood = 3,   
    }
}
