﻿using Domain.Enum;

namespace Domain.Entities
{
    public class Product : BaseModel
    {
        public string Name { get; set; }
        public EProductType TypeProduct { get; set; }
        public int QuantityInStock { get; set; }
        public float Value { get; set; }
        public int QuantitiyChoose { get; set; }
    }
}
