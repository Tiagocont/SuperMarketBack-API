﻿namespace Domain.Entities
{
    public class Sale : BaseModel
    {
        public string UserName { get; set; }
        public ICollection<ProductChoose> Products { get; set; }
        public double SaleValue { get; set; }
        public string CepSale { get; set; }
        public double DeliveryValue { get; set; }
        public double TotalValue { get; set; }
    }

    public class ProductChoose : BaseModel 
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public double Value { get; set; }
        public int QuantityChoose { get; set; }
    }
}
