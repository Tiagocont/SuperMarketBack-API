﻿namespace Domain.Entities
{
    public abstract class BaseModel
    {
        public int Id { get; set; }
    }
}
