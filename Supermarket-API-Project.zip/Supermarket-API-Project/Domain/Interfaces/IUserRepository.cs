﻿using Domain.Entities;

namespace Domain.Interfaces
{
    public interface IUserRepository
    {
        Task<User> Get(int id);
        void Delete(int id);
        void Post(User entity);
        Task<User> Put(User entity);
        Task<IEnumerable<User>> GetAll();
    }
}
