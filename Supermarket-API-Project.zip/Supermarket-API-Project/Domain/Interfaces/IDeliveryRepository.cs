﻿namespace Domain.Interfaces
{
    public interface IDeliveryRepository
    {
        Task<(double lat, double lon)> GetCoordinates(string cep);
        Task<double> DistanceCalculator((double lat, double lon) origem, (double lat, double lon) destino);
    }
}
