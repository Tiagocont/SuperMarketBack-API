﻿using Domain.Entities;

namespace Domain.Interfaces
{
    public interface ISaleRepository
    {
        Task<Sale> Get(int id);
        void Delete(int id);
        void Post(Sale entity);
        Task<Sale> Put(Sale entity);
        Task<IEnumerable<Sale>> GetAll();
    }
}
