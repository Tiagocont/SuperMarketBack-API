﻿using Domain.Entities;

namespace Domain.Interfaces
{
    public interface IProductRepository
    {
        Task<Product> Get(int id); 
        Task<IEnumerable<Product>> GetAll(); 
        void Delete(int id); 
        void Post(Product entity); 
        Task<Product> Put(Product produto);
    }
}
