﻿using Application.Interfaces;
using Application.ViewModels.Sale;
using Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket_API_Project.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class SaleController : ControllerBase
    {
        protected readonly ISaleService _saleService;
        public SaleController(ISaleService service)
        {
            _saleService = service;
        }


        [HttpPost]
        public async Task<Sale> Post(EntrySaleViewModel entity)
        {
            return await _saleService.Post(entity);
        }

        [HttpPut]
        public async Task<Sale> Put(Sale entity)
        {
            return await _saleService.Put(entity);
        }

        [HttpDelete]
        public async Task<string> Delete(int id)
        {
            return await _saleService.Delete(id);
        }

        [HttpGet]
        public async Task<Sale> Get(int id)
        {
            return await _saleService.Get(id);
        }
        
        [HttpGet, Route("List")]
        public async Task<IEnumerable<Sale>> GetAll()
        {
            return await _saleService.GetAll();
        }
    }
}
