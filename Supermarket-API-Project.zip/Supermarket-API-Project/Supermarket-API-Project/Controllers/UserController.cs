﻿using Application.Interfaces;
using Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket_API_Project.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class UserController : ControllerBase
    {
        protected readonly IUserService _userService;
        public UserController(IUserService service)
        {
            _userService = service;
        }

        [HttpPost]
        public async Task<User> Post(User entity)
        {
            return await _userService.Post(entity);
        }
        
        [HttpPut]
        public async Task<User> Put(User entity)
        {
            return await _userService.Put(entity);
        }
        
        [HttpDelete]
        public async Task<string> Delete(int id)
        {
            return await _userService.Delete(id);
        }
        
        [HttpGet]
        public async Task<User> Get(int id)
        {
            return await _userService.Get(id);
        }
        
        [HttpGet, Route("List")]
        public async Task<IEnumerable<User>> GetAll()
        {
            return await _userService.GetAll();
        }
    }
}
