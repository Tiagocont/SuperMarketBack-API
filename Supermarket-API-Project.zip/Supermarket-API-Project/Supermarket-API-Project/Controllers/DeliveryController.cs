﻿using Application.Interfaces;
using Application.Services;
using Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket_API_Project.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class DeliveryController
    {
        protected readonly IDeliveryService _deliveryService;
        public DeliveryController(IDeliveryService service)
        {
            _deliveryService = service;
        }

        [HttpPost]
        public async Task<double> Post(string postalCode)
        {
            return await _deliveryService.GetDeliveryValue(postalCode);
        }
    }
}
