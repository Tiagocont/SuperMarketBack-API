﻿using Application.Interfaces;
using Domain.Entities;
using Microsoft.AspNetCore.Mvc;

namespace Supermarket_API_Project.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class ProductController : ControllerBase
    {
        protected readonly IProductService _productService;
        public ProductController(IProductService service)
        {
            _productService = service;
        }

        [HttpPost]
        public async Task<Product> Post(Product entitity)
        {
            return await _productService.Post(entitity);
        }

        [HttpPut]
        public async Task<Product> Put(Product entity)
        {
            return await _productService.Put(entity);
        }

        [HttpDelete]
        public async Task<string> Delete(int id)
        {
            return await _productService.Delete(id);
        }

        [HttpGet]
        public async Task<Product> Get(int id)
        {
            return await _productService.Get(id);
        }

        [HttpGet, Route("List")]
        public async Task<IEnumerable<Product>> GetAll()
        {
            return await _productService.GetAll();
        }
    }
}
