﻿namespace Application.Interfaces
{
    public interface IDeliveryService
    {
        Task<double> GetDeliveryValue(string postalCode);
    }
}
