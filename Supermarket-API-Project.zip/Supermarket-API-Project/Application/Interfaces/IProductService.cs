﻿using Domain.Entities;

namespace Application.Interfaces
{
    public interface IProductService
    {
        Task<Product> Get(int id);
        Task<IEnumerable<Product>> GetAll();
        Task<Product> Post(Product product);
        Task<Product> Put(Product product);
        Task<string> Delete(int id);
    }
}
