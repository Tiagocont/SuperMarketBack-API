﻿using Domain.Entities;

namespace Application.Interfaces
{
    public interface IUserService
    {
        Task<User> Get(int id);
        Task<IEnumerable<User>> GetAll();
        Task<User> Post(User product);
        Task<User> Put(User product);
        Task<string> Delete(int id);
    }
}
