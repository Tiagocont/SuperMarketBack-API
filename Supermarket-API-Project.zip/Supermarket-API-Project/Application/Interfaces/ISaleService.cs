﻿using Application.ViewModels.Sale;
using Domain.Entities;

namespace Application.Interfaces
{
    public interface ISaleService
    {
        Task<Sale> Get(int id);
        Task<IEnumerable<Sale>> GetAll();
        Task<Sale> Post(EntrySaleViewModel product);
        Task<Sale> Put(Sale product);
        Task<string> Delete(int id);
    }
}
