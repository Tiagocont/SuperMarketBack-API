﻿using Application.Interfaces;
using Domain.Entities;
using Domain.Interfaces;
using System.Runtime.CompilerServices;

namespace Application.Services
{
    public class ProductService : IProductService
    {
        private readonly IProductRepository _productRepository;
        private readonly IDeliveryService _deliveryService;

        public ProductService(IProductRepository productRepository, IDeliveryService deliveryService)
        {
            _productRepository = productRepository;
            _deliveryService = deliveryService;
        }

        public async Task<Product> Get(int id)
        {
            return await _productRepository.Get(id);
        }

        public async Task<IEnumerable<Product>> GetAll()
        {
            return await _productRepository.GetAll();
        }

        public async Task<Product> Post(Product product)
        {
            _productRepository.Post(product);
            return product;
        }

        public async Task<Product> Put(Product product)
        {
            return await _productRepository.Put(product);
        }

        public async Task<string> Delete(int id)
        {
            _productRepository.Delete(id);
            return "Produto apagado";
        }
    }
}
