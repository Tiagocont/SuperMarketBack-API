﻿using Application.Interfaces;
using Domain.Interfaces;

namespace Application.Services
{
    public class DeliveryService : IDeliveryService
    {
        private static readonly string OpenRouteServiceApiKey = "SUA_API_KEY"; 
        private static readonly string OsascoEndereco = "Av. dos Autonomistas, 123 - Vila Yara, Osasco, Brasil";
        private readonly IDeliveryRepository _deliveryRepository;

        public DeliveryService(IDeliveryRepository deliveryRepository)
        {
            _deliveryRepository = deliveryRepository;
        }

        public async Task<double> GetDeliveryValue(string postalCode)
        {
            var cep = postalCode;  

            var coordenadasDestino = await _deliveryRepository.GetCoordinates(cep);

            var coordenadasOsasco = await _deliveryRepository.GetCoordinates("06090-020");

            double distanciaKm = await _deliveryRepository.DistanceCalculator(coordenadasOsasco, coordenadasDestino);

            double preco = distanciaKm * 1.50;

            return preco;
        }

    }
}
