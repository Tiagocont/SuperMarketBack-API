﻿using Application.Interfaces;
using Application.ViewModels.Sale;
using Domain.Entities;
using Domain.Interfaces;

namespace Application.Services
{
    public class SaleService : ISaleService
    {
        private readonly ISaleRepository _saleRepository;
        protected readonly IProductService _productService;
        protected readonly IDeliveryService _deliveryService;
        

        public SaleService(ISaleRepository saleRepository, IProductService productService, IDeliveryService deliveryService)
        {
            _saleRepository = saleRepository;
            _productService = productService;
            _deliveryService = deliveryService;
        }

        public async Task<Sale> Get(int id)
        {
            return await _saleRepository.Get(id);
        }

        public async Task<IEnumerable<Sale>> GetAll()
        {
            return await _saleRepository.GetAll();
        }

        public async Task<Sale> Post(EntrySaleViewModel saleViewModel)
        {
            double valorCompra = 0;
            ICollection<ProductChoose> produtos = [];
            foreach (var item in saleViewModel.Products) {
                var produto = await _productService.Get(item.Id);
                if (produto != null)
                {
                    if(item.QuantityChoose > produto.QuantityInStock)
                    {
                        return null;
                    }
                    var produtoEmEstoque = produto.QuantityInStock - item.QuantityChoose;
                    produto.QuantityInStock = produtoEmEstoque;
                    var atualizarEstoque = new Product()
                    {
                        Id = item.Id,
                        Name = produto.Name,
                        QuantitiyChoose = item.QuantityChoose, //esse nem precisa mais
                        QuantityInStock = produtoEmEstoque,
                        TypeProduct = produto.TypeProduct,
                        Value = produto.Value,
                    };
                    valorCompra += item.QuantityChoose * produto.Value;
                    var produtoModel = new ProductChoose()
                    {
                        Id = item.Id,
                        Name = produto.Name,
                        QuantityChoose = item.QuantityChoose,
                        Value = produto.Value,
                    };
                    produtos.Add(produtoModel);
                    var produtoAtualizado = await _productService.Put(atualizarEstoque);
                }
            }
            var deliveryValue = await _deliveryService.GetDeliveryValue(saleViewModel.CepSale);

            var saleEntity = new Sale()
            {
                Id = saleViewModel.Id,
                CepSale = saleViewModel.CepSale,
                DeliveryValue = deliveryValue,
                SaleValue = valorCompra,
                TotalValue = valorCompra + deliveryValue,
                UserName = saleViewModel.UserName,
                Products = produtos
            };

            _saleRepository.Post(saleEntity);
            return saleEntity;
        }

        public async Task<Sale> Put(Sale product)
        {
            return await _saleRepository.Put(product);
        }

        public async Task<string> Delete(int id)
        {
            _saleRepository.Delete(id);
            return "Produto apagado";
        }
    }
}
