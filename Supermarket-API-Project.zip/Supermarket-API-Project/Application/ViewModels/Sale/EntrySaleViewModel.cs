﻿using Domain.Entities;

namespace Application.ViewModels.Sale
{
    public class EntrySaleViewModel : BaseModel
    {
        public string UserName { get; set; }
        public ICollection<ProductChooseViewModel> Products { get; set; }
        public string CepSale { get; set; }
    }

    public class ProductChooseViewModel
    {
        public int Id { get; set; }
        public int QuantityChoose { get; set; }
    }
}
